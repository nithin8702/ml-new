Matplot-lib-Basics
==================

Matplot lib Basics. Ipython Notebook
